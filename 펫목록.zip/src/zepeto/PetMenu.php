<?php

namespace zepeto;

use pocketmine\Server;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityLevelChangeEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\entity\Effect;
use pocketmine\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\item\Item;
use pocketmine\lang\BaseLang;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\block\Block;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat;
use pocketmine\utils\Config;
use jojoe77777\FormAPI;
use xpilow\XpilowPetMenu;
use onebone\economyapi\EconomyAPI;

class PetMenu extends PluginBase implements Listener {

    /** @var Main $instance */
    private static $instance;
	
	public $plugin;

	public function onEnable() : void{
	    self::$instance = $this;
        $this->getLogger()->info(TextFormat::GREEN . "PetMenu xpilow Enable");
        $this->eco = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");	
	}
	
	public static function getInstance() : self{
	    return self::$instance;
	}
 

       
    public function onCommand(CommandSender $p, Command $cmd, string $label, array $array) : bool{
        if($kmt->getName() == "펫"){
            $this->Menu($p);
        }
        return true;
    }
    
    public function Menu($sender){ 
        $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, int $data = null) {
            $result = $data;
            if($result === null){
                return true;
            }             
            switch($result){
                case 0:
                $this->dForm($sender);
                break;
                case 1:
                $this->Remove($sender);
                break;
                case 2:
                $this->ChangeName($sender);
                break;
                case 3:
                $this->TogglePet($sender);
                break;
                        

                }
            });
            $name = $sender->getName();
            $money = $this->eco->myMoney($sender);
            $form->setTitle("펫  기능목록 §6[§r1§f/§r2§6]");
            $form->setContent("§a{$name} \n §a돈 §e: §b{$money}");
            $form->addButton("§8펫 상점",0,"textures/ui/arrow_active");
            $form->addButton("§8펫제거",0,"textures/ui/arrow_active");
            $form->addButton("§8펫 이름 변경",0,"textures/ui/arrow_active");
            $form->addButton("§8펫 변경",0,"textures/ui/arrow_active");
            $form->sendToPlayer($sender);
            return $form;
    }

    public function dForm(Player $o){
        $f = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createCustomForm(function (Player $o, array $data){
            $re = $data[0];
            if($re === null){
                return true;
            }
            if($re == 0){
				if(!$o->sendMessage("§b늑대가 성공적으로 구매되었습니다")){
            	    $money = $this->eco->myMoney($o);
				    $wolf = 150000;
				    if($money >= $wolf){
					    $this->eco->reduceMoney($o, $wolf);
					    $this->getServer()->getCommandMap()->dispatch($o, "spawnpet Wolf $data[1]");
					    return true;
            }else{
				    $o->sendMessage("§c돈이 충분하지 않습니다");
				    }
                }
            }
            if($re == 1){
            	if(!$o->sendMessage("§b라마가 성공적으로 구매되었습니다")){
            	    $money = $this->eco->myMoney($o);
				    $llama = 150000;
				    if($money >= $llama){
					    $this->eco->reduceMoney($o, $llama);
					    $this->getServer()->getCommandMap()->dispatch($o, "spawnpet Llama $data[1]");
					    return true;
            }else{
				    $o->sendMessage("§c돈이 부족 합니다");
				    }
                }
            }
            if($re == 2){
            	if(!$o->sendMessage("§b닭이 성공적으로 구매되었습니다")){
            	    $money = $this->eco->myMoney($o);
				    $chicken = 150000;
				    if($money >= $chicken){
					    $this->eco->reduceMoney($o, $chicken);
					    $this->getServer()->getCommandMap()->dispatch($o, "spawnpet Chicken $data[1]");
					    return true;
            }else{
				    $o->sendMessage("§c돈이 부족 합니다");
				    }
                }
            }
            if($re == 3){
            	if(!$o->sendMessage("§b토끼가 성공적으로 구매 되었슴니다")){
            	    $money = $this->eco->myMoney($o);
				    $rabbit = 150000;
				    if($money >= $rabbit){
					    $this->eco->reduceMoney($o, $rabbit);
					    $this->getServer()->getCommandMap()->dispatch($o, "spawnpet Rabbit $data[1]");
					    return true;
            }else{
				    $o->sendMessage("§c돈이 부족 합니다");
				    }
                }
            }
            if($re == 4){
            	if(!$o->sendMessage("§b북극곰이 성공적으로 구매 되었습니다")){
            	    $money = $this->eco->myMoney($o);
				    $bear = 150000;
				    if($money >= $bear){
					    $this->eco->reduceMoney($o, $bear);
					    $this->getServer()->getCommandMap()->dispatch($o, "spawnpet PolarBear $data[1]");
					    return true;
            }else{
				    $o->sendMessage("§c돈이 부족 합니다");
				    }
                }
            }
            if($re == 5){
            	if(!$o->sendMessage("§b오셀롯이 성공적으로 구매 되었습니다")){
            	    $money = $this->eco->myMoney($o);
				    $ocelot = 150000;
				    if($money >= $ocelot){
					    $this->eco->reduceMoney($o, $ocelot);
					    $this->getServer()->getCommandMap()->dispatch($o, "spawnpet Ocelot $data[1]");
					    return true;
            }else{
				    $o->sendMessage("§c돈이 부족 합니다g");
				    }
                }
            }
               $this->getServer()->getCommandMap()->dispatch($o, "spawnpet $data[2]"); 
            }
         });
            $isim = $o->getName();
            $name = $o->getName();
            $money = $this->eco->myMoney($o);
            $wolf = 150000;
            $llama = 150000;
            $chicken = 150000;
            $rabbit = 150000;
            $bear = 150000;
            $ocelot = 150000;
            $f->setTitle("§0펫상점");
            $f->addDropdown("§e§b{$name} \n 돈§e: §b{$money}§9$\n §f펫 선택:", [
                "늑대 §a" . $wolf . "§9$",
                "라마 §a" . $llama . "§9$",
                "닭 §a" . $chicken . "§9$",
                "토까 §a" . $rabbit . "§9$",
                "북극곰 §a" . $bear . "§9$",
                "오셀롯 §a" . $ocelot . "§9$",
                            ]);
                            $f->addInput("§f펫이름:", "Name: 0");
            $f->sendToPlayer($o);
    }

    public function Remove($player){
		$formapi = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $formapi->createCustomForm(function(Player $player, $data){
			$result = $data[0];
			if($result === null){
				return true;
	       }
	       $command = "removepet $data[0]";
	       $this->getServer()->getCommandMap()->dispatch($player, $command);
		});
		$on = $this->getServer()->getCommandMap()->dispatch($player, "tooglepet all");
		$form->setTitle("펫 제거");
		$form->addInput("펫 이름:", "Nama: 0");
	    $form->sendToPlayer($player);
    }
    
    public function TogglePet($player){
		$formapi = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $formapi->createCustomForm(function(Player $player, $data){
			$result = $data[0];
			if($result === null){
				return true;
	       }
	       $command = "togglepet $data[0]";
	       $this->getServer()->getCommandMap()->dispatch($player, $command);
		});
		$form->setTitle("TOGGLE PET");
		$form->addInput("Pet Name:", "Name: 0");
		$form->addToggle("§fOFF§6/§fON");
	    $form->sendToPlayer($player);
    }
	
	public function ChangeName($player){
		$formapi = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $formapi->createCustomForm(function(Player $player, $data){
			$result = $data[0];
			if($result === null){
                return true;
            }
            $command = "changepetname $data[0] $data[1]";
            $this->getServer()->getCommandMap()->dispatch($player, $command);
        });
        $form->setTitle("이름 변경");
        $form->addInput("그전이름:", "그전 >\\\<");
        $form->addInput("새로운 이름:", "새로운 >\\\<");
        $form->sendToPlayer($player);
    }

}

?>